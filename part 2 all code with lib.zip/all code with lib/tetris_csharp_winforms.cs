<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tetris HD</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    canvas {
      image-rendering: pixelated;
    }
  </style>
</head>
<body class="bg-gray-900 text-white min-h-screen flex items-center justify-center">
  <div class="flex flex-col items-center gap-4">
    <h1 class="text-4xl font-bold">🎮 Tetris HD</h1>

    <!-- Device Selection -->
    <div class="flex gap-2">
      <button onclick="setDevice('pc')" class="bg-blue-700 hover:bg-blue-800 px-4 py-2 rounded-xl">💻 Main di PC</button>
      <button onclick="setDevice('mobile')" class="bg-green-700 hover:bg-green-800 px-4 py-2 rounded-xl">📱 Main di Mobile</button>
    </div>

    <div class="grid grid-cols-3 gap-4 items-start">
      <!-- Side Panel -->
      <div class="space-y-2">
        <div class="bg-gray-800 rounded-xl p-4 shadow-xl">
          <p>🧱 <strong>Next Block</strong></p>
          <canvas id="next" width="80" height="80" class="bg-black mx-auto"></canvas>
        </div>
        <div class="bg-gray-800 rounded-xl p-4 shadow-xl text-sm">
          <p>💯 Score: <span id="score">0</span></p>
          <p>🔝 High Score: <span id="highScore">0</span></p>
          <p>⏱ Time: <span id="time">00:00</span></p>
          <p>🕓 Best Time: <span id="bestTime">00:00</span></p>
        </div>
        <div class="flex justify-center gap-2">
          <button onclick="restartGame()" class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl">🔄 Restart</button>
          <button onclick="pauseGame()" class="bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded-xl">⏸️ Pause</button>
        </div>

        <!-- Mobile Controls -->
        <div id="mobileControls" class="mt-4 hidden space-y-2">
          <p class="text-center text-sm">📱 Kontrol Mobile:</p>
          <div class="flex justify-center gap-4">
            <button onclick="playerMove(-1)" class="bg-white text-black px-3 py-2 rounded">⬅️</button>
            <button onclick="playerMove(1)" class="bg-white text-black px-3 py-2 rounded">➡️</button>
            <button onclick="playerDrop()" class="bg-white text-black px-3 py-2 rounded">⬇️</button>
          </div>
        </div>
      </div>

      <!-- Game Area -->
      <canvas id="tetris" width="240" height="400" class="col-span-2 bg-black rounded-xl shadow-xl"></canvas>
    </div>
  </div>

  <script>
    let device = 'pc';
    function setDevice(mode) {
      device = mode;
      const controls = document.getElementById('mobileControls');
      if (mode === 'mobile') controls.classList.remove('hidden');
      else controls.classList.add('hidden');
    }

    // ... seluruh kode JavaScript tetap sama di bawah sini ...

    document.addEventListener('keydown', e => {
      if (device === 'pc') {
        if (e.key === 'a' || e.key === 'A') playerMove(-1);
        else if (e.key === 'd' || e.key === 'D') playerMove(1);
        else if (e.key === 's' || e.key === 'S') playerDrop();
        else if (e.key === 'q') playerRotate(-1);
        else if (e.key === 'w') playerRotate(1);
      }
    });
  </script>
</body>
</html>
