import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

public class TetrisGame extends JPanel implements ActionListener {
    private final int BOARD_WIDTH = 10;
    private final int BOARD_HEIGHT = 20;
    private Timer timer;
    private boolean isFallingFinished = false;
    private boolean isPaused = false;
    private int score = 0;
    private int highScore = 0;
    private JLabel statusbar;
    private JLabel scorebar;

    public TetrisGame(Tetris parent) {
        setFocusable(true);
        statusbar = parent.getStatusBar();
        scorebar = parent.getScoreBar();
        addKeyListener(new TAdapter());
        timer = new Timer();
        timer.schedule(new GameCycle(), 0, 400);
    }

    class GameCycle extends TimerTask {
        public void run() {
            if (isPaused) return;
            if (isFallingFinished) {
                isFallingFinished = false;
                // spawn new piece
            } else {
                // move down
            }
            repaint();
        }
    }

    class TAdapter extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            if (isPaused) return;
            int keycode = e.getKeyCode();
            switch (keycode) {
                case KeyEvent.VK_LEFT:
                    // move left
                    break;
                case KeyEvent.VK_RIGHT:
                    // move right
                    break;
                case KeyEvent.VK_DOWN:
                    // drop faster
                    break;
                case KeyEvent.VK_UP:
                    // rotate
                    break;
                case KeyEvent.VK_SPACE:
                    isPaused = !isPaused;
                    statusbar.setText(isPaused ? "Paused" : "Playing");
                    break;
            }
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        g.setColor(Color.DARK_GRAY);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.GREEN);
        g.drawString("Score: " + score, 10, 20);
    }

    @Override
    public void actionPerformed(ActionEvent e) {}

    public void updateScore(int points) {
        score += points;
        if (score > highScore) highScore = score;
        scorebar.setText("Score: " + score + " | High Score: " + highScore);
    }

    public void restartGame() {
        score = 0;
        scorebar.setText("Score: 0 | High Score: " + highScore);
    }
}

class Tetris extends JFrame {
    private JLabel statusbar;
    private JLabel scorebar;

    public Tetris() {
        statusbar = new JLabel("Ready");
        scorebar = new JLabel("Score: 0 | High Score: 0");
        add(statusbar, BorderLayout.SOUTH);
        add(scorebar, BorderLayout.NORTH);
        TetrisGame game = new TetrisGame(this);
        add(game);
        setTitle("Tetris Java");
        setSize(300, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public JLabel getStatusBar() {
        return statusbar;
    }

    public JLabel getScoreBar() {
        return scorebar;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Tetris game = new Tetris();
            game.setVisible(true);
        });
    }
}
