#include <SFML/Graphics.hpp>

int main() {
    // Buat jendela berukuran 800x600
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Window");

    // Buat persegi berwarna merah
    sf::RectangleShape rectangle(sf::Vector2f(200, 150));
    rectangle.setFillColor(sf::Color::Red);
    rectangle.setPosition(300, 225);  // posisi tengah layar

    // Loop utama
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            // Tutup jendela jika X diklik
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();               // Bersihkan layar
        window.draw(rectangle);       // Gambar persegi
        window.display();             // Tampilkan ke layar
    }

    return 0;
}
