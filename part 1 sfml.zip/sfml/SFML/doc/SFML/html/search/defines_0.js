var searchData=
[
  ['sfml_5fapi_5fexport_0',['SFML_API_EXPORT',['../Config_8hpp.html#ab2d9ba01221055369f9707a4d7b528c2',1,'Config.hpp']]],
  ['sfml_5fapi_5fimport_1',['SFML_API_IMPORT',['../Config_8hpp.html#aba0bbe5791bee6633caa835c7f6a12a4',1,'Config.hpp']]],
  ['sfml_5faudio_5fapi_2',['SFML_AUDIO_API',['../Audio_2Export_8hpp.html#a4d34c0f253824ac49bdd93545913eb89',1,'Export.hpp']]],
  ['sfml_5fdebug_3',['SFML_DEBUG',['../Config_8hpp.html#a90cd534d01b83efcf7e6769551c2a3db',1,'Config.hpp']]],
  ['sfml_5fdefine_5fdiscrete_5fgpu_5fpreference_4',['SFML_DEFINE_DISCRETE_GPU_PREFERENCE',['../GpuPreference_8hpp.html#ab0233c2d867cbd561036ed2440a4fec0',1,'GpuPreference.hpp']]],
  ['sfml_5fdeprecated_5',['SFML_DEPRECATED',['../Config_8hpp.html#a9d22ae32bba2961ae9abc7e40f035fc7',1,'Config.hpp']]],
  ['sfml_5fgraphics_5fapi_6',['SFML_GRAPHICS_API',['../Graphics_2Export_8hpp.html#ab84c9f1035e146917de3bc0f98d72b35',1,'Export.hpp']]],
  ['sfml_5fnetwork_5fapi_7',['SFML_NETWORK_API',['../Network_2Export_8hpp.html#ac5d46d4ffd98e947e28c54d051b338e7',1,'Export.hpp']]],
  ['sfml_5fsystem_5fapi_8',['SFML_SYSTEM_API',['../System_2Export_8hpp.html#a6476c9e422606477a4c23d92b1d79a1f',1,'Export.hpp']]],
  ['sfml_5fversion_5fmajor_9',['SFML_VERSION_MAJOR',['../Config_8hpp.html#ab601e78ee9806b7ef75b242681af3bf2',1,'Config.hpp']]],
  ['sfml_5fversion_5fminor_10',['SFML_VERSION_MINOR',['../Config_8hpp.html#a91a4f1f9aeae335e13bb4cfa8f018865',1,'Config.hpp']]],
  ['sfml_5fversion_5fpatch_11',['SFML_VERSION_PATCH',['../Config_8hpp.html#acccd4412c83e570fbc4d1d5638b035b3',1,'Config.hpp']]],
  ['sfml_5fwindow_5fapi_12',['SFML_WINDOW_API',['../Window_2Export_8hpp.html#a1ab885b7907ee088350359516d68be64',1,'Export.hpp']]]
];
